﻿using System;
using System.Data;
using Microsoft.Data.SqlClient;

namespace Databaze_aplikace
{
    internal class Program
    {
        private static readonly string _connectionString =
            @"Server=(localdb)\MSSQLLocalDB;Database=knihadb;Trusted_Connection=True;Encrypt=True;TrustServerCertificate=True;";

        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.WriteLine("Správa databáze knih (knihadb)");
            Console.WriteLine("----------------------------------");

            while (true)
            {
                VypisMenu();
                Console.Write("Volba: ");
                var volba = Console.ReadLine();

                try
                {
                    switch (volba)
                    {
                        case "1": ZobrazVsechnyKnihy(); break;
                        case "2": ZobrazVsechnyAutory(); break;
                        case "3": ZobrazVsechnyRecenze(); break;
                        case "4": ZobrazVsechnyRecenzenty(); break;
                        case "5": ZobrazKnihyAutora(); break;
                        case "6": ZobrazRecenzeKnihy(); break;
                        case "7": ZobrazRecenzeRecenzenta(); break;
                        case "8": VlozAutora(); break;
                        case "9": VlozKnihu(); break;
                        case "10": VlozRecenzenta(); break;
                        case "11": VlozRecenzi(); break;
                        case "12": PropojAutoraAKnihu(); break;
                        case "0":
                            Console.WriteLine("Konec aplikace.");
                            return;
                        default:
                            Console.WriteLine("Neplatná volba.");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Chyba: " + ex.Message);
                }

                Console.WriteLine();
                Console.WriteLine("Enter pro pokračování...");
                Console.ReadLine();
            }
        }

        private static void VypisMenu()
        {
            Console.WriteLine();
            Console.WriteLine("MENU");
            Console.WriteLine("1  - Zobraz všechny knihy");
            Console.WriteLine("2  - Zobraz všechny autory");
            Console.WriteLine("3  - Zobraz všechny recenze");
            Console.WriteLine("4  - Zobraz všechny recenzenty");
            Console.WriteLine("5  - Zobraz knihy vybraného autora");
            Console.WriteLine("6  - Zobraz recenze vybrané knihy");
            Console.WriteLine("7  - Zobraz recenze vybraného recenzenta");
            Console.WriteLine("8  - Vlož nového autora");
            Console.WriteLine("9  - Vlož novou knihu (a přiřaď autory)");
            Console.WriteLine("10 - Vlož nového recenzenta");
            Console.WriteLine("11 - Vlož novou recenzi");
            Console.WriteLine("12 - Dodatečně přiřaď autora ke knize");
            Console.WriteLine("0  - Konec");
            Console.WriteLine();
        }

        // ---------- ZOBRAZOVÁNÍ ----------
        private static void ZobrazVsechnyKnihy()
        {
            const string sql = @"SELECT id, Nazev, rok_vydani, Zanr FROM Knihy ORDER BY Nazev;";
            using (var cn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand(sql, cn))
            {
                cn.Open();
                using (var r = cmd.ExecuteReader())
                {
                    Console.WriteLine("Knihy:");
                    while (r.Read())
                    {
                        Console.WriteLine($"[{r.GetInt32(0)}] {r.GetString(1)}" +
                                          $"{(r.IsDBNull(2) ? "" : $" ({r.GetInt32(2)})")}" +
                                          $"{(r.IsDBNull(3) ? "" : $", žánr: {r.GetString(3)}")}");
                    }
                }
            }
        }

        private static void ZobrazVsechnyAutory()
        {
            const string sql = @"SELECT id, Jmeno, Prijmeni FROM Autori ORDER BY Prijmeni, Jmeno;";
            using (var cn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand(sql, cn))
            {
                cn.Open();
                using (var r = cmd.ExecuteReader())
                {
                    Console.WriteLine("Autoři:");
                    while (r.Read())
                    {
                        string cele = (r.IsDBNull(1) ? "" : r.GetString(1)) + " " + (r.IsDBNull(2) ? "" : r.GetString(2));
                        Console.WriteLine($"[{r.GetInt32(0)}] {cele.Trim()}");
                    }
                }
            }
        }

        private static void ZobrazVsechnyRecenzenty()
        {
            const string sql = @"SELECT id, uzivatelske_jmeno, email FROM Recenzenti ORDER BY uzivatelske_jmeno;";
            using (var cn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand(sql, cn))
            {
                cn.Open();
                using (var r = cmd.ExecuteReader())
                {
                    Console.WriteLine("Recenzenti:");
                    while (r.Read())
                    {
                        Console.WriteLine($"[{r.GetInt32(0)}] {r.GetString(1)}" +
                                          $"{(r.IsDBNull(2) ? "" : $" ({r.GetString(2)})")}");
                    }
                }
            }
        }

        private static void ZobrazVsechnyRecenze()
        {
            const string sql = @"
SELECT rc.id, k.Nazev, rz.uzivatelske_jmeno, rc.Hodnoceni, rc.datum
FROM Recenze rc
INNER JOIN Knihy k ON rc.id_knihy = k.id
INNER JOIN Recenzenti rz ON rc.id_recenzent = rz.id
ORDER BY rc.id;";
            using (var cn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand(sql, cn))
            {
                cn.Open();
                using (var r = cmd.ExecuteReader())
                {
                    Console.WriteLine("Recenze:");
                    while (r.Read())
                    {
                        Console.WriteLine($"[{r.GetInt32(0)}] Kniha: {r.GetString(1)} | Recenzent: {r.GetString(2)} | Hodnocení: {r.GetInt32(3)} | Datum: {r.GetDateTime(4):yyyy-MM-dd}");
                    }
                }
            }
        }

        private static void ZobrazKnihyAutora()
        {
            ZobrazVsechnyAutory();
            int idAutora = ReadInt("ID autora: ");
            const string sql = @"
SELECT k.id, k.Nazev, k.rok_vydani, k.Zanr
FROM Mapping_Table m
INNER JOIN Knihy k ON m.Id_Knihy = k.id
WHERE m.Id_Autora = @a
ORDER BY k.Nazev;";
            using (var cn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand(sql, cn))
            {
                cmd.Parameters.Add("@a", SqlDbType.Int).Value = idAutora;
                cn.Open();
                using (var r = cmd.ExecuteReader())
                {
                    Console.WriteLine("Knihy autora:");
                    bool any = false;
                    while (r.Read())
                    {
                        any = true;
                        Console.WriteLine($"[{r.GetInt32(0)}] {r.GetString(1)}" +
                                          $"{(r.IsDBNull(2) ? "" : $" ({r.GetInt32(2)})")}" +
                                          $"{(r.IsDBNull(3) ? "" : $", žánr: {r.GetString(3)}")}");
                    }
                    if (!any) Console.WriteLine("Autor nemá přiřazené knihy.");
                }
            }
        }

        private static void ZobrazRecenzeKnihy()
        {
            ZobrazVsechnyKnihy();
            int idKnihy = ReadInt("ID knihy: ");
            const string sql = @"
SELECT rc.id, rz.uzivatelske_jmeno, rc.Hodnoceni, rc.datum
FROM Recenze rc
INNER JOIN Recenzenti rz ON rc.id_recenzent = rz.id
WHERE rc.id_knihy = @k
ORDER BY rc.id;";
            using (var cn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand(sql, cn))
            {
                cmd.Parameters.Add("@k", SqlDbType.Int).Value = idKnihy;
                cn.Open();
                using (var r = cmd.ExecuteReader())
                {
                    Console.WriteLine("Recenze knihy:");
                    bool any = false;
                    while (r.Read())
                    {
                        any = true;
                        Console.WriteLine($"[{r.GetInt32(0)}] Recenzent: {r.GetString(1)} | Hodnocení: {r.GetInt32(2)} | Datum: {r.GetDateTime(3):yyyy-MM-dd}");
                    }
                    if (!any) Console.WriteLine("Žádné recenze.");
                }
            }
        }

        private static void ZobrazRecenzeRecenzenta()
        {
            ZobrazVsechnyRecenzenty();
            int idRecenzenta = ReadInt("ID recenzenta: ");
            const string sql = @"
SELECT rc.id, k.Nazev, rc.Hodnoceni, rc.datum
FROM Recenze rc
INNER JOIN Knihy k ON rc.id_knihy = k.id
WHERE rc.id_recenzent = @r
ORDER BY rc.id;";
            using (var cn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand(sql, cn))
            {
                cmd.Parameters.Add("@r", SqlDbType.Int).Value = idRecenzenta;
                cn.Open();
                using (var r = cmd.ExecuteReader())
                {
                    Console.WriteLine("Recenze recenzenta:");
                    bool any = false;
                    while (r.Read())
                    {
                        any = true;
                        Console.WriteLine($"[{r.GetInt32(0)}] Kniha: {r.GetString(1)} | Hodnocení: {r.GetInt32(2)} | Datum: {r.GetDateTime(3):yyyy-MM-dd}");
                    }
                    if (!any) Console.WriteLine("Žádné recenze.");
                }
            }
        }

        // ---------- VKLÁDÁNÍ ----------
        private static void VlozAutora()
        {
            Console.Write("Jméno: ");
            var jmeno = Console.ReadLine();
            Console.Write("Příjmení: ");
            var prijmeni = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(jmeno) || string.IsNullOrWhiteSpace(prijmeni))
            {
                Console.WriteLine("Jméno i příjmení musí být vyplněno.");
                return;
            }

            const string sql = @"INSERT INTO Autori(Jmeno, Prijmeni) VALUES(@j,@p); SELECT SCOPE_IDENTITY();";
            using (var cn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand(sql, cn))
            {
                cmd.Parameters.Add("@j", SqlDbType.NVarChar, 100).Value = jmeno.Trim();
                cmd.Parameters.Add("@p", SqlDbType.NVarChar, 100).Value = prijmeni.Trim();
                cn.Open();
                int id = Convert.ToInt32(cmd.ExecuteScalar());
                Console.WriteLine("Autor vložen, ID: " + id);
            }
        }

        private static void VlozKnihu()
        {
            Console.Write("Název: ");
            var nazev = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(nazev))
            {
                Console.WriteLine("Název nesmí být prázdný.");
                return;
            }

            Console.Write("Rok vydání (Enter = neznámé): ");
            var rokText = Console.ReadLine();
            int? rok = null;
            int rokParsed;
            if (!string.IsNullOrWhiteSpace(rokText) && int.TryParse(rokText, out rokParsed))
                rok = rokParsed;

            Console.Write("Žánr (Enter = neznámý): ");
            var zanr = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(zanr)) zanr = null;

            ZobrazVsechnyAutory();
            Console.Write("Počet autorů k přiřazení: ");
            int pocet = ReadInt(null);
            if (pocet < 1)
            {
                Console.WriteLine("Musí být alespoň jeden autor.");
                return;
            }
            var autorIds = new int[pocet];
            for (int i = 0; i < pocet; i++)
            {
                autorIds[i] = ReadInt($"ID autora #{i + 1}: ");
            }

            using (var cn = new SqlConnection(_connectionString))
            {
                cn.Open();
                using (var tx = cn.BeginTransaction())
                {
                    try
                    {
                        var cmdBook = new SqlCommand(
                            @"INSERT INTO Knihy(Nazev, rok_vydani, Zanr) VALUES(@n,@r,@z); SELECT SCOPE_IDENTITY();",
                            cn, tx);
                        cmdBook.Parameters.Add("@n", SqlDbType.NVarChar, 300).Value = nazev.Trim();
                        cmdBook.Parameters.Add("@r", SqlDbType.Int).Value = rok.HasValue ? (object)rok.Value : DBNull.Value;
                        cmdBook.Parameters.Add("@z", SqlDbType.NVarChar, 200).Value = zanr != null ? (object)zanr.Trim() : DBNull.Value;

                        int idKnihy = Convert.ToInt32(cmdBook.ExecuteScalar());

                        var cmdMap = new SqlCommand(
                            @"INSERT INTO Mapping_Table(Id_Autora, Id_Knihy) VALUES(@a,@k);",
                            cn, tx);
                        var pA = cmdMap.Parameters.Add("@a", SqlDbType.Int);
                        var pK = cmdMap.Parameters.Add("@k", SqlDbType.Int);
                        pK.Value = idKnihy;

                        foreach (var aId in autorIds)
                        {
                            pA.Value = aId;
                            cmdMap.ExecuteNonQuery();
                        }

                        tx.Commit();
                        Console.WriteLine("Kniha vložena, ID: " + idKnihy);
                    }
                    catch (Exception ex)
                    {
                        tx.Rollback();
                        Console.WriteLine("Chyba při vkládání knihy: " + ex.Message);
                    }
                }
            }
        }

        private static void VlozRecenzenta()
        {
            Console.Write("Jméno recenzenta: ");
            var jmeno = Console.ReadLine();
            Console.Write("Email (Enter = žádný): ");
            var email = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(jmeno))
            {
                Console.WriteLine("Jméno nesmí být prázdné.");
                return;
            }

            const string sql = @"INSERT INTO Recenzenti(uzivatelske_jmeno, email) VALUES(@j,@e); SELECT SCOPE_IDENTITY();";
            using (var cn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand(sql, cn))
            {
                cmd.Parameters.Add("@j", SqlDbType.NVarChar, 150).Value = jmeno.Trim();
                cmd.Parameters.Add("@e", SqlDbType.NVarChar, 200).Value = string.IsNullOrWhiteSpace(email) ? (object)DBNull.Value : email.Trim();
                cn.Open();
                int id = Convert.ToInt32(cmd.ExecuteScalar());
                Console.WriteLine("Recenzent vložen, ID: " + id);
            }
        }

        private static void VlozRecenzi()
        {
            ZobrazVsechnyKnihy();
            int idKnihy = ReadInt("ID knihy: ");
            ZobrazVsechnyRecenzenty();
            int idRecenzenta = ReadInt("ID recenzenta: ");

            int hodnoceni = ReadInt("Hodnocení (0-10): ");
            if (hodnoceni < 0 || hodnoceni > 10)
            {
                Console.WriteLine("Hodnocení mimo rozsah.");
                return;
            }

            Console.Write("Datum (yyyy-MM-dd, Enter = dnešní): ");
            var datumText = Console.ReadLine();
            DateTime datum;
            if (string.IsNullOrWhiteSpace(datumText))
                datum = DateTime.Today;
            else if (!DateTime.TryParse(datumText, out datum))
            {
                Console.WriteLine("Neplatný formát data.");
                return;
            }

            const string sql = @"INSERT INTO Recenze(id_knihy, id_recenzent, datum, Hodnoceni)
VALUES(@k,@r,@d,@h); SELECT SCOPE_IDENTITY();";
            using (var cn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand(sql, cn))
            {
                cmd.Parameters.Add("@k", SqlDbType.Int).Value = idKnihy;
                cmd.Parameters.Add("@r", SqlDbType.Int).Value = idRecenzenta;
                cmd.Parameters.Add("@d", SqlDbType.Date).Value = datum.Date;
                cmd.Parameters.Add("@h", SqlDbType.Int).Value = hodnoceni;

                cn.Open();
                int id = Convert.ToInt32(cmd.ExecuteScalar());
                Console.WriteLine("Recenze vložena, ID: " + id);
            }
        }

        // ---------- DODATEČNÉ PROPOJENÍ ----------
        private static void PropojAutoraAKnihu()
        {
            ZobrazVsechnyKnihy();
            int idKnihy = ReadInt("ID knihy: ");
            ZobrazVsechnyAutory();
            int idAutora = ReadInt("ID autora: ");

            const string checkSql = @"SELECT COUNT(*) FROM Mapping_Table WHERE Id_Autora=@a AND Id_Knihy=@k;";
            const string insertSql = @"INSERT INTO Mapping_Table(Id_Autora, Id_Knihy) VALUES(@a,@k);";

            using (var cn = new SqlConnection(_connectionString))
            using (var check = new SqlCommand(checkSql, cn))
            {
                check.Parameters.Add("@a", SqlDbType.Int).Value = idAutora;
                check.Parameters.Add("@k", SqlDbType.Int).Value = idKnihy;
                cn.Open();
                int exists = Convert.ToInt32(check.ExecuteScalar());
                if (exists > 0)
                {
                    Console.WriteLine("Tento autor je již přiřazen k dané knize.");
                    return;
                }

                using (var ins = new SqlCommand(insertSql, cn))
                {
                    ins.Parameters.Add("@a", SqlDbType.Int).Value = idAutora;
                    ins.Parameters.Add("@k", SqlDbType.Int).Value = idKnihy;
                    ins.ExecuteNonQuery();
                    Console.WriteLine("Autor úspěšně přiřazen.");
                }
            }
        }

        // ---------- Pomocné ----------
        private static int ReadInt(string prompt)
        {
            while (true)
            {
                if (!string.IsNullOrEmpty(prompt))
                    Console.Write(prompt);

                var line = Console.ReadLine();
                int value;
                if (int.TryParse(line, out value))
                    return value;

                Console.WriteLine("Zadejte celé číslo.");
            }
        }
    }
}
