﻿using System;
using System.Collections.Generic;

namespace EF_DatabaseApp1.Models;

public partial class Autori
{
    public int Id { get; set; }

    public string Jmeno { get; set; } = null!;

    public string Prijmeni { get; set; } = null!;

    public virtual ICollection<Knihy> IdKnihas { get; set; } = new List<Knihy>();
}
