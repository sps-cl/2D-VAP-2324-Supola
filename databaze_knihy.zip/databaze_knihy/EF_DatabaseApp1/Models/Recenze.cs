﻿using System;
using System.Collections.Generic;

namespace EF_DatabaseApp1.Models;

public partial class Recenze
{
    public int Id { get; set; }

    public int? IdRecenzent { get; set; }

    public int IdKnihy { get; set; }

    public DateOnly Datum { get; set; }

    public int Hodnoceni { get; set; }

    public virtual Knihy IdKnihyNavigation { get; set; } = null!;

    public virtual Recenzenti? IdRecenzentNavigation { get; set; }
}
