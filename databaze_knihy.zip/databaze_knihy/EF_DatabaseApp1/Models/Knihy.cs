﻿using System;
using System.Collections.Generic;

namespace EF_DatabaseApp1.Models;

public partial class Knihy
{
    public int Id { get; set; }

    public string Nazev { get; set; } = null!;

    public int RokVydani { get; set; }

    public string Zanr { get; set; } = null!;

    public virtual ICollection<Recenze> Recenzes { get; set; } = new List<Recenze>();

    public virtual ICollection<Autori> IdAutors { get; set; } = new List<Autori>();
}
