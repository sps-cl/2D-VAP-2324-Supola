﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EF_DatabaseApp1.Models;

public partial class KnihadbContext : DbContext
{
    public KnihadbContext()
    {
    }

    public KnihadbContext(DbContextOptions<KnihadbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Autori> Autoris { get; set; }

    public virtual DbSet<Knihy> Knihies { get; set; }

    public virtual DbSet<Recenze> Recenzes { get; set; }

    public virtual DbSet<Recenzenti> Recenzentis { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=(localdb)\\MSSQLLocalDB;Database=knihadb;Trusted_Connection=True;Encrypt=True;TrustServerCertificate=True;MultipleActiveResultSets=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Autori>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Autori__3213E83FE706CD98");

            entity.ToTable("Autori");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Jmeno)
                .HasMaxLength(100)
                .HasColumnName("jmeno");
            entity.Property(e => e.Prijmeni)
                .HasMaxLength(100)
                .HasColumnName("prijmeni");
        });

        modelBuilder.Entity<Knihy>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Knihy__3213E83FAFFC2D2B");

            entity.ToTable("Knihy");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Nazev)
                .HasMaxLength(100)
                .HasColumnName("nazev");
            entity.Property(e => e.RokVydani).HasColumnName("rok_vydani");
            entity.Property(e => e.Zanr)
                .HasMaxLength(50)
                .HasColumnName("zanr");

            entity.HasMany(d => d.IdAutors).WithMany(p => p.IdKnihas)
                .UsingEntity<Dictionary<string, object>>(
                    "AutoriKnih",
                    r => r.HasOne<Autori>().WithMany()
                        .HasForeignKey("IdAutor")
                        .HasConstraintName("FK__Autori_kn__id_au__4222D4EF"),
                    l => l.HasOne<Knihy>().WithMany()
                        .HasForeignKey("IdKniha")
                        .HasConstraintName("FK__Autori_kn__id_kn__412EB0B6"),
                    j =>
                    {
                        j.HasKey("IdKniha", "IdAutor").HasName("PK__Autori_k__EC2C8A6A52795AD9");
                        j.ToTable("Autori_knih");
                        j.HasIndex(new[] { "IdAutor" }, "Autori_knih_index_0");
                        j.IndexerProperty<int>("IdKniha").HasColumnName("id_kniha");
                        j.IndexerProperty<int>("IdAutor").HasColumnName("id_autor");
                    });
        });

        modelBuilder.Entity<Recenze>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Recenze__3213E83F0A3464DB");

            entity.ToTable("Recenze");

            entity.HasIndex(e => e.IdRecenzent, "Recenze_index_0");

            entity.HasIndex(e => e.IdKnihy, "Recenze_index_1");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Datum)
                .HasDefaultValueSql("(getdate())")
                .HasColumnName("datum");
            entity.Property(e => e.Hodnoceni).HasColumnName("hodnoceni");
            entity.Property(e => e.IdKnihy).HasColumnName("id_knihy");
            entity.Property(e => e.IdRecenzent).HasColumnName("id_recenzent");

            entity.HasOne(d => d.IdKnihyNavigation).WithMany(p => p.Recenzes)
                .HasForeignKey(d => d.IdKnihy)
                .HasConstraintName("FK__Recenze__id_knih__403A8C7D");

            entity.HasOne(d => d.IdRecenzentNavigation).WithMany(p => p.Recenzes)
                .HasForeignKey(d => d.IdRecenzent)
                .OnDelete(DeleteBehavior.SetNull)
                .HasConstraintName("FK__Recenze__id_rece__4316F928");
        });

        modelBuilder.Entity<Recenzenti>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Recenzen__3213E83F122D38E6");

            entity.ToTable("Recenzenti");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Email)
                .HasMaxLength(100)
                .HasColumnName("email");
            entity.Property(e => e.UzivatelskeJmeno)
                .HasMaxLength(100)
                .HasColumnName("uzivatelske_jmeno");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
