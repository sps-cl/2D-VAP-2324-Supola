﻿using System;
using System.Collections.Generic;

namespace EF_DatabaseApp1.Models;

public partial class Recenzenti
{
    public int Id { get; set; }

    public string UzivatelskeJmeno { get; set; } = null!;

    public string Email { get; set; } = null!;

    public virtual ICollection<Recenze> Recenzes { get; set; } = new List<Recenze>();
}
